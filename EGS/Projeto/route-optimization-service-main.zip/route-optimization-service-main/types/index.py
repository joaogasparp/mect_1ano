from typing import Tuple, List, Dict, Any

Coordinate = Tuple[float, float]

Route = List[str]

ApiResponse = Dict[str, Any]

TrafficData = Dict[str, Any]
