from utils import haversine
from controllers.traffic_data import fetch_route_data
import heapq

def reconstruct_path(came_from, current):
    total_path = [current]
    while current in came_from:
        current = came_from[current]
        total_path.append(current)
    total_path.reverse()
    return total_path

def astar(start, goal, api_key, heuristic_func=haversine):
    route_data = fetch_route_data(api_key, start, goal)
    if not route_data:
        return None, float('inf'), 0, []

    steps = route_data['features'][0]['properties']['segments'][0]['steps']
    path = []
    for step in steps:
        for point in step['way_points']:
            path.append({
                'latitude': route_data['features'][0]['geometry']['coordinates'][point][1],
                'longitude': route_data['features'][0]['geometry']['coordinates'][point][0],
                'instruction': step['instruction']
            })
    
    duration_seconds = route_data['features'][0]['properties']['segments'][0]['duration']
    distance_meters = route_data['features'][0]['properties']['segments'][0]['distance']
    duration_minutes = duration_seconds / 60
    distance_kilometers = distance_meters / 1000

    return path, duration_minutes, distance_kilometers, [step['instruction'] for step in steps]
