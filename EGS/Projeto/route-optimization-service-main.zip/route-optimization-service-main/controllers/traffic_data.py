import requests

def fetch_route_data(api_key, origin, destination):
    start = f"{origin[1]},{origin[0]}"
    end = f"{destination[1]},{destination[0]}"
    
    url = f"https://api.openrouteservice.org/v2/directions/driving-car?api_key={api_key}&start={start}&end={end}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def integrate_traffic_data(graph, coordinates, api_key):
    for node in graph:
        for neighbor in graph[node]:
            if node in coordinates and neighbor in coordinates:
                route_data = fetch_route_data(api_key, coordinates[node], coordinates[neighbor])
                if route_data and 'features' in route_data and len(route_data['features']) > 0:
                    duration_seconds = route_data['features'][0]['properties']['segments'][0]['duration']
                    distance_meters = route_data['features'][0]['properties']['segments'][0]['distance']
                    duration_minutes = duration_seconds / 60
                    distance_kilometers = distance_meters / 1000
                    steps = route_data['features'][0]['properties']['segments'][0]['steps']
                    graph[node][neighbor] = {
                        'duration_minutes': duration_minutes,
                        'distance_kilometers': distance_kilometers,
                        'steps': steps,
                        'geometry': route_data['features'][0]['geometry']['coordinates']
                    }
                else:
                    graph[node][neighbor] = {
                        'duration_minutes': float('inf'),
                        'distance_kilometers': float('inf'),
                        'steps': [],
                        'geometry': []
                    }
    
    return graph
