## Instalação

1. Cria e/ou ativa o ambiente virtual:
   ```sh
   python -m venv venv
   .\venv\Scripts\activate   # No Windows
   source venv/bin/activate  # No Linux
   ```

2. Instala as dependências:
   ```sh
   pip install -r requirements.txt
   ```

## Uso

Para executar o serviço, utiliza o seguinte comando:

```sh
python -m uvicorn main:app --reload
```

Isso vai iniciaro servidor FastAPI. Poderás acessar a API [aqui](http://localhost:8000/api/route).
Para razões experimentais verifica [este link](http://localhost:8000/api/route?start_lat=38.7167&start_lon=-9.1399&goal_lat=40.6405&goal_lon=-8.6538) que mostra o resultado da API para a origem de Lisboa e o destino de Aveiro.

## Exemplo de Uso da API

### Endpoint: `/api/route`

**Método:** GET

**Parâmetros de Consulta:**
- `start_lat`: Latitude da cidade de partida (por exemplo, 38.7167).
- `start_lon`: Longitude da cidade de partida (por exemplo, -9.1399).
- `goal_lat`: Latitude da cidade de destino (por exemplo, 40.6405).
- `goal_lon`: Longitude da cidade de destino (por exemplo, -8.6538).

**Resposta:**
```json
{
  "route_id": "route123",
  "start_location": {
    "latitude": 38.7167,
    "longitude": -9.1399
  },
  "end_location": {
    "latitude": 40.6405,
    "longitude": -8.6538
  },
  "total_distance_km": 263.9187,
  "estimated_time_min": 163.97,
  "route_path": [
    {
      "latitude": 38.717388,
      "longitude": -9.139525,
      "instruction": "Head east on Travessa da Pena"
    },
    {
      "latitude": 38.717561,
      "longitude": -9.138957,
      "instruction": "Head east on Travessa da Pena"
    },
    {
      "latitude": 38.717561,
      "longitude": -9.138957,
      "instruction": "Turn right onto Calçada de Santana"
    }
  ]
}
```
