from fastapi import FastAPI, APIRouter, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from astar import astar
from pydantic import BaseModel
from typing import List

router = APIRouter()

class Location(BaseModel):
    latitude: float
    longitude: float

class RoutePath(BaseModel):
    latitude: float
    longitude: float
    instruction: str

class RouteResponse(BaseModel):
    route_id: str
    start_location: Location
    end_location: Location
    total_distance_km: float
    estimated_time_min: float
    route_path: List[RoutePath]

@router.get("/route", response_model=RouteResponse)
async def get_route(start_lat: float, start_lon: float, goal_lat: float, goal_lon: float):
    api_key = '5b3ce3597851110001cf6248ee5a7a86129a47428d23c9e22dcc9cb2'
    start = (start_lat, start_lon)
    goal = (goal_lat, goal_lon)
    path, cost, total_distance, instructions = astar(start, goal, api_key)
    if path is None:
        raise HTTPException(status_code=404, detail="Path not found.")
    
    route_path = []
    for step in path:
        route_path.append(RoutePath(
            latitude=step['latitude'],
            longitude=step['longitude'],
            instruction=step['instruction']
        ))
    
    return RouteResponse(
        route_id="route123",
        start_location=Location(latitude=start_lat, longitude=start_lon),
        end_location=Location(latitude=goal_lat, longitude=goal_lon),
        total_distance_km=total_distance,
        estimated_time_min=cost,
        route_path=route_path
    )


@router.get("/ping", tags=["Health Check"])
async def ping():
    return {"message": "Route Optimization service is running."}